$(function() {
	
	 $('#cover').delay(10000).slideUp(5000);
	
	
	/*$('#what-we-do').animate( {
		 "margin-top": "-48px"
	},10000);*/
		
	
	
});